/* Catálogo Grupo Blue — un catálogo por plataforma.
   Página pública: <body data-mode="public" data-base="">  → lee data.json de su carpeta.
   Panel admin:    <body data-mode="admin"  data-base="../"> → lee y guarda data.json con la API de GitHub. */
(function(){
'use strict';
var MODE=document.body.getAttribute('data-mode')||'public';
var BASE=document.body.getAttribute('data-base')||'';
var COUNTRY_LIB={GT:{name:'Guatemala',symbol:'Q',decimals:2},CR:{name:'Costa Rica',symbol:'₡',decimals:0},HN:{name:'Honduras',symbol:'L',decimals:2},SV:{name:'El Salvador',symbol:'$',decimals:2},NI:{name:'Nicaragua',symbol:'C$',decimals:2},PA:{name:'Panamá',symbol:'$',decimals:2},MX:{name:'México',symbol:'$',decimals:2},CO:{name:'Colombia',symbol:'$',decimals:0},PE:{name:'Perú',symbol:'S/',decimals:2},EC:{name:'Ecuador',symbol:'$',decimals:2},CL:{name:'Chile',symbol:'$',decimals:0},DO:{name:'Rep. Dominicana',symbol:'RD$',decimals:2},PY:{name:'Paraguay',symbol:'₲',decimals:0},BO:{name:'Bolivia',symbol:'Bs',decimals:2},US:{name:'Estados Unidos',symbol:'US$',decimals:2}};
var STATUS={disponible:{l:'Disponible',c:'ok'},pocas:{l:'Pocas unidades',c:'warn'},agotado:{l:'Agotado',c:'bad'},pronto:{l:'Próximamente',c:'info'}};
var BADGES=['','Nuevo','Más vendido','Oferta','Bienestar'];
var TINTS=['--t1','--t2','--t3','--t4','--t5','--t6'];
var TOKEN_KEY='gb-github-token',REPO_KEY='gb-github-repo';
var ICON={
  wa:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.5 11.6a8.4 8.4 0 0 1-12.3 7.5L3.5 20.5l1.5-4.5a8.4 8.4 0 1 1 15.5-4.4z"/><path d="M9 9.5c.3 2 1.8 3.8 4 4.6l1.2-1.1 2 .9"/></svg>',
  search:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>'
};

function $(s,r){return (r||document).querySelector(s)}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function uid(p){return p+Math.random().toString(36).slice(2,8)+Date.now().toString(36).slice(-4)}
function clone(o){return JSON.parse(JSON.stringify(o))}
function uniq(a){return a.filter(function(v,i){return a.indexOf(v)===i})}
function norm(s){return String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'')}
function lsGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function lsSet(k,v){try{if(v==null)localStorage.removeItem(k);else localStorage.setItem(k,v)}catch(e){}}

var state=null;
var ui={country:'',q:'',cat:'Todas',sort:'rel',scope:'country'};
var admin=MODE==='admin',dirty=0,saving=false,modal=null,ed=null,stg=null;
var gh=null;               // {token, owner, repo, dir, branch}
var loadedSha=null;        // sha de data.json al cargar
var origImages={};         // fotos que existían al cargar
var pending={};            // fotos nuevas aún sin publicar: ruta -> dataURL
var preview={};            // fotos ya publicadas en esta sesión (GitHub Pages tarda en servirlas)
var app=document.getElementById('app');

function normalize(d){
  d=d||{};d.platform=d.platform||{};d.platform.name=d.platform.name||'Catálogo';d.platform.countries=d.platform.countries||[];
  d.brand=d.brand||{name:'Grupo Blue'};d.categories=d.categories&&d.categories.length?d.categories:['Otros'];d.products=d.products||[];
  return d;
}
function P(){return state.platform}
function C(cc){return COUNTRY_LIB[cc]||{name:cc,symbol:'',decimals:2}}
function fmt(n,cc){if(n==null||n===''||isNaN(n))return '—';var c=C(cc);return (c.symbol?c.symbol+' ':'')+Number(n).toLocaleString('es-GT',{minimumFractionDigits:c.decimals,maximumFractionDigits:c.decimals})}
function fmtDate(s){try{return new Date(s).toLocaleDateString('es-GT',{day:'numeric',month:'short',year:'numeric'})}catch(e){return ''}}
function tint(cat){var i=state.categories.indexOf(cat);if(i<0)i=0;return 'var('+TINTS[i%TINTS.length]+')'}
function initials(n){var w=String(n||'').split(/\s+/).filter(function(x){return x.length>2});return (w.slice(0,2).map(function(x){return x[0].toUpperCase()}).join(''))||'•'}
function inMarket(x,cc){return !!(x.markets&&x.markets[cc]&&x.markets[cc].active)}
function mk(x,cc){return (x.markets&&x.markets[cc])||{}}
function countIn(cc){return state.products.filter(function(x){return inMarket(x,cc)}).length}
function waNumber(){return String(P().whatsapp||'').replace(/\D/g,'')}
function waLink(n,msg){return 'https://wa.me/'+n+'?text='+encodeURIComponent(msg)}
function safeUrl(u){u=String(u||'').trim();return /^https?:\/\//i.test(u)?u:''}
function gainOf(x){var m=mk(x,ui.country);return (m.price!=null&&m.suggested!=null)?m.suggested-m.price:null}
function parseNum(v){var s=String(v||'').replace(/[^\d.,]/g,'');if(!s)return null;if(s.indexOf('.')>-1&&s.indexOf(',')>-1)s=s.replace(/,/g,'');else if(s.indexOf(',')>-1)s=/,\d{3}$/.test(s)?s.replace(/,/g,''):s.replace(',','.');var n=parseFloat(s);return isNaN(n)?null:n}
function imgSrc(p){return pending[p]||preview[p]||(BASE+p)}
function publicUrl(){try{return new URL(admin?'../':'./',location.href).href.split('#')[0]}catch(e){return ''}}

function applyHash(){
  var h=(location.hash||'').slice(1).toUpperCase(),cs=P().countries;
  ui.country=(h&&cs.indexOf(h)>-1)?h:(cs.indexOf(ui.country)>-1?ui.country:(cs[0]||''));
}

function visible(){var cc=ui.country;return (admin&&ui.scope==='all')?state.products.slice():state.products.filter(function(x){return inMarket(x,cc)})}
function filtered(){
  var list=visible(),cc=ui.country;
  if(ui.cat!=='Todas')list=list.filter(function(x){return x.category===ui.cat});
  var q=norm(ui.q.trim());
  if(q)list=list.filter(function(x){return norm([x.name,x.category,x.description,x.badge,mk(x,cc).code].join(' ')).indexOf(q)>-1});
  var out=function(x){return mk(x,cc).status==='agotado'||!inMarket(x,cc)?1:0};
  var sorts={
    rel:function(a,b){return out(a)-out(b)},
    price:function(a,b){var x=mk(a,cc).price,y=mk(b,cc).price;return (x==null?1e15:x)-(y==null?1e15:y)},
    priceDesc:function(a,b){var x=mk(a,cc).price,y=mk(b,cc).price;return (y==null?-1:y)-(x==null?-1:x)},
    gain:function(a,b){var x=gainOf(a),y=gainOf(b);return (y==null?-1e15:y)-(x==null?-1e15:x)},
    name:function(a,b){return a.name.localeCompare(b.name,'es')}
  };
  return list.sort(sorts[ui.sort]||sorts.rel);
}

/* ---------- Render ---------- */
function render(){
  var p=P();if(p.countries.indexOf(ui.country)<0)ui.country=p.countries[0]||'';
  var b=state.brand,cc=ui.country,wa=waNumber();
  var qFocus=document.activeElement&&document.activeElement.id==='q';
  document.title=(admin?'Panel · ':'')+'Catálogo '+p.name+' · '+(b.name||'Grupo Blue');
  var html='';
  if(admin)html+=adminBar();
  html+='<header class="wrap top"><div class="brand"><div class="mark" aria-hidden="true">'+esc(initials(b.name||'Grupo Blue'))+'</div><div><h1>'+esc(b.name||'Grupo Blue')+'</h1><p>'+(b.tagline?esc(b.tagline)+' · ':'')+'Catálogo para dropshippers de <strong>'+esc(p.name)+'</strong></p></div></div>'+
    (wa?'<a class="btn wa" href="'+esc(waLink(wa,'Hola '+(b.name||'')+', vengo del catálogo de '+p.name+(cc?' ('+C(cc).name+')':'')+'.'))+'" target="_blank" rel="noopener">'+ICON.wa+' Escríbenos</a>':'')+'</header>';
  if(b.highlight||p.note)html+='<div class="wrap intro">'+(b.highlight?'<span class="ribbon"><b>Nuevo</b>'+esc(b.highlight)+'</span>':'')+(p.note?'<p class="pnote">'+esc(p.note)+'</p>':'')+'</div>';
  if(admin)html+=adminNotices();
  html+='<nav class="wrap countries" role="tablist" aria-label="País">'+p.countries.map(function(c){return '<button class="ctab" role="tab" aria-selected="'+(c===cc)+'" data-act="country" data-cc="'+c+'"><span class="iso">'+c+'</span>'+esc(C(c).name)+'<span class="cnt num">'+countIn(c)+'</span></button>'}).join('')+(admin?'<button class="ctab add" data-act="settings">+ País</button>':'')+'</nav>';
  html+='<section class="wrap tools"><label class="search">'+ICON.search+'<input id="q" type="search" placeholder="Buscar por nombre, categoría o ID…" value="'+esc(ui.q)+'" aria-label="Buscar productos" autocomplete="off"></label>'+
    '<span class="sel"><select id="sort" class="select" aria-label="Ordenar">'+[['rel','Destacados'],['price','Precio: menor a mayor'],['priceDesc','Precio: mayor a menor'],['gain','Mayor ganancia'],['name','Nombre A–Z']].map(function(o){return '<option value="'+o[0]+'"'+(ui.sort===o[0]?' selected':'')+'>'+o[1]+'</option>'}).join('')+'</select></span></section>';
  html+='<div class="wrap" id="results"></div>';
  html+='<footer class="wrap foot"><span>'+esc(b.name||'Grupo Blue')+' · Proveeduría para dropshippers de '+esc(p.name)+'</span><span>'+(cc?'Precios en '+esc(C(cc).name)+' ('+esc(C(cc).symbol)+')':'')+(state.updatedAt?' · Actualizado '+esc(fmtDate(state.updatedAt)):'')+'</span></footer>';
  if(wa)html+='<a class="wa-float" href="'+esc(waLink(wa,'Hola '+(b.name||'')+', tengo una consulta sobre el catálogo de '+p.name+(cc?' ('+C(cc).name+')':'')+'.'))+'" target="_blank" rel="noopener">'+ICON.wa+'<span>Consultas</span></a>';
  app.innerHTML=html;
  renderResults();
  if(qFocus){var q=$('#q');if(q){q.focus();q.setSelectionRange(q.value.length,q.value.length)}}
}

function adminBar(){
  return '<div class="adminbar"><div class="wrap"><span class="ab-title"><span class="mini">'+esc(initials(state.brand.name))+'</span>Panel · '+esc(P().name)+'</span><span class="ab-spacer"></span>'+
    '<a class="ab-btn link" href="'+esc(publicUrl())+'" target="_blank" rel="noopener">Ver catálogo ↗</a><button class="ab-btn" data-act="share">Compartir</button><button class="ab-btn" data-act="settings">Ajustes</button><button class="ab-btn" data-act="logout">Salir</button>'+
    '<button class="ab-btn ab-save" data-act="save"'+((!dirty||saving)?' disabled':'')+'>'+(saving?'Publicando…':dirty?'Guardar y publicar ('+dirty+')':'Todo publicado')+'</button></div></div>';
}
function adminNotices(){
  var n=[];
  if(!waNumber())n.push('<div class="notice"><span class="grow">Agrega el WhatsApp de '+esc(P().name)+' para activar el botón de Consultas.</span><button class="btn sm" data-act="settings">Agregar número</button></div>');
  if(dirty)n.push('<div class="notice info"><span class="grow">Tienes cambios sin publicar. Los dropshippers los verán cuando toques Guardar y publicar.</span></div>');
  return n.length?'<div class="wrap notices">'+n.join('')+'</div>':'';
}
function empty(t,s,a){return '<div class="empty"><h3>'+esc(t)+'</h3><p>'+esc(s)+'</p>'+(a||'')+'</div>'}

function renderResults(){
  var el=document.getElementById('results');if(!el)return;
  var p=P(),cc=ui.country;
  if(!cc){el.innerHTML=empty('Aún no hay países en '+p.name,admin?'Agrega los países donde vendes con esta plataforma.':'Pronto verás productos aquí.',admin?'<button class="btn primary" data-act="settings">Agregar país</button>':'');return}
  var base=visible();
  var cats=['Todas'].concat(state.categories.filter(function(c){return base.some(function(x){return x.category===c})}),uniq(base.map(function(x){return x.category}).filter(function(c){return c&&state.categories.indexOf(c)<0})));
  if(cats.indexOf(ui.cat)<0)ui.cat='Todas';
  var list=filtered(),h='';
  if(cats.length>2)h+='<div class="filters" role="group" aria-label="Categorías">'+cats.map(function(c){return '<button class="chip" data-act="cat" data-v="'+esc(c)+'" aria-pressed="'+(c===ui.cat)+'">'+esc(c)+'</button>'}).join('')+'</div>';
  h+='<div class="rhead"><p class="count"><strong class="num">'+list.length+'</strong> '+(list.length===1?'producto':'productos')+' '+(admin&&ui.scope==='all'?'en total':'en '+esc(C(cc).name))+'</p>'+
    (admin?'<div class="rtools"><div class="seg" role="group" aria-label="Mostrar"><button data-act="scope" data-v="country" aria-pressed="'+(ui.scope==='country')+'">Solo '+esc(C(cc).name)+'</button><button data-act="scope" data-v="all" aria-pressed="'+(ui.scope==='all')+'">Todos los países</button></div><button class="btn primary" data-act="add-product">+ Agregar producto</button></div>':'')+'</div>';
  if(!list.length)h+=base.length?empty('Sin resultados','Prueba con otra palabra o categoría.',''):empty('Aún no hay productos en '+C(cc).name,admin?'Agrega el primero o activa este país en productos que ya tienes.':'Vuelve pronto o escríbenos para conocer el inventario.',admin?'<button class="btn primary" data-act="add-product">+ Agregar producto</button>':'');
  else h+='<div class="grid">'+list.map(cardHTML).join('')+'</div>';
  el.innerHTML=h;
}

function placeholder(x){return '<div class="ph" style="--tint:'+tint(x.category)+'"><span class="ph-ini">'+esc(initials(x.name))+'</span><span class="ph-cat">'+esc(x.category||'')+'</span></div>'}
function badgeHTML(x){return x.badge?'<span class="badge'+(x.badge==='Nuevo'||x.badge==='Oferta'?' hot':'')+'">'+esc(x.badge)+'</span>':''}
function cardHTML(x){
  var cc=ui.country,m=mk(x,cc),on=inMarket(x,cc),st=STATUS[m.status]||STATUS.disponible,img=(x.images||[])[0],g=gainOf(x);
  var prices=on?'<div class="prices"><div class="p-main"><span>Precio proveedor</span><strong class="num">'+fmt(m.price,cc)+'</strong></div>'+
      (m.suggested!=null?'<div class="p-sub"><span>Sugerido <b class="num">'+fmt(m.suggested,cc)+'</b></span>'+(g!=null&&g>0?'<span class="gain num">+'+fmt(g,cc)+'</span>':'')+'</div>':'')+'</div>'
    :'<div class="prices"><span class="pill">No está en '+esc(C(cc).name)+'</span></div>';
  return '<article class="card'+(on?'':' is-off')+(on&&m.status==='agotado'?' is-out':'')+'" role="button" tabindex="0" data-act="open" data-id="'+esc(x.id)+'" aria-label="'+esc(x.name)+'">'+
    '<div class="card-media">'+(img?'<img src="'+esc(imgSrc(img))+'" alt="'+esc(x.name)+'" loading="lazy" decoding="async">':placeholder(x))+'<div class="badges">'+badgeHTML(x)+'</div>'+(admin?'<span class="edit-hint">Editar</span>':'')+'</div>'+
    '<div class="card-body"><span class="eyebrow">'+esc(x.category)+'</span><h3 class="card-title">'+esc(x.name)+'</h3>'+(on&&m.status&&m.status!=='disponible'?'<span class="pill '+st.c+'">'+st.l+'</span>':'')+prices+'</div></article>';
}

/* ---------- Modales ---------- */
function openModal(inner,cls){
  closeModal();
  var root=document.createElement('div');root.className='modal-back';
  root.innerHTML='<div class="modal '+(cls||'')+'" role="dialog" aria-modal="true">'+inner+'</div>';
  root.addEventListener('mousedown',function(e){if(e.target===root)closeModal()});
  document.body.appendChild(root);document.body.classList.add('no-scroll');modal=root;
  var f=root.querySelector('input:not([type=file]):not([readonly]),textarea,.x');if(f)f.focus();
}
function closeModal(){if(modal){modal.remove();modal=null;document.body.classList.remove('no-scroll')}ed=null;stg=null}
function head(eyebrow,title){return '<div class="m-head"><div><span class="eyebrow">'+eyebrow+'</span><h2 class="m-title">'+title+'</h2></div><button class="x" data-act="close" aria-label="Cerrar">✕</button></div>'}

function openDetail(id){
  var x=state.products.find(function(p){return p.id===id});if(!x)return;
  var p=P(),cc=ui.country,m=mk(x,cc),on=inMarket(x,cc),st=STATUS[m.status]||STATUS.disponible,g=gainOf(x),imgs=x.images||[];
  var others=p.countries.filter(function(c){return c!==cc&&inMarket(x,c)}),wa=waNumber(),media=safeUrl(x.media);
  var msg='Hola '+(state.brand.name||'')+', me interesa este producto del catálogo de '+p.name+' ('+C(cc).name+'):\n'+x.name+(m.code?'\nID: '+m.code:'');
  openModal(head(esc(x.category)+' · '+esc(p.name)+' '+esc(C(cc).name),esc(x.name))+
    '<div class="m-body"><div class="dt"><div><div class="dt-main" id="dt-main">'+(imgs.length?'<img src="'+esc(imgSrc(imgs[0]))+'" alt="'+esc(x.name)+'">':placeholder(x))+'</div>'+
    (imgs.length>1?'<div class="thumbs">'+imgs.map(function(i,k){return '<button class="thumb" data-act="thumb" data-img="'+esc(i)+'" aria-pressed="'+(k===0)+'" aria-label="Foto '+(k+1)+'"><img src="'+esc(imgSrc(i))+'" alt=""></button>'}).join('')+'</div>':'')+'</div>'+
    '<div class="dt-info"><div class="dt-pills">'+(on?'<span class="pill '+st.c+'">'+st.l+'</span>':'<span class="pill">No está en '+esc(C(cc).name)+'</span>')+badgeHTML(x)+'</div>'+
    (on?'<div class="ptable"><div><span>Precio proveedor</span><strong class="num">'+fmt(m.price,cc)+'</strong></div><div><span>Venta sugerida</span><strong class="num">'+fmt(m.suggested,cc)+'</strong></div><div class="g"><span>Tu ganancia</span><strong class="num">'+(g!=null?fmt(g,cc):'—')+'</strong></div></div>':'')+
    (on&&m.code?'<div class="idrow"><span>ID en '+esc(p.name)+'</span><strong class="num">'+esc(m.code)+'</strong><button class="btn sm" data-act="copy" data-text="'+esc(m.code)+'">Copiar ID</button></div>':'')+
    (x.description?'<p class="desc">'+esc(x.description)+'</p>':'')+
    (others.length?'<p class="also">También disponible en '+others.map(function(c){return esc(C(c).name)}).join(', ')+'.</p>':'')+
    '<div class="dt-actions">'+(wa?'<a class="btn wa" href="'+esc(waLink(wa,msg))+'" target="_blank" rel="noopener">'+ICON.wa+' Consultar por WhatsApp</a>':'')+(media?'<a class="btn" href="'+esc(media)+'" target="_blank" rel="noopener">Material de venta ↗</a>':'')+'</div>'+
    (wa?'<p class="hint">WhatsApp: +'+esc(wa)+'</p>':'')+'</div></div></div>');
}

function openEditor(id){
  var p=P(),src=id?state.products.find(function(x){return x.id===id}):null,m0={};
  if(ui.country)m0[ui.country]={active:true,price:null,suggested:null,status:'disponible',code:''};
  var e=src?clone(src):{id:uid('p'),name:'',category:ui.cat!=='Todas'?ui.cat:(state.categories[0]||'Otros'),badge:'',description:'',media:'',images:[],markets:m0};
  e.images=e.images||[];e.markets=e.markets||{};
  var isNew=!src,cats=uniq(state.categories.concat([e.category]).filter(Boolean));
  var body='<div class="m-body"><div class="form">'+
    '<div class="field"><label for="ed-name">Nombre del producto</label><input class="input" id="ed-name" value="'+esc(e.name)+'" placeholder="Ej. Colágeno hidrolizado 300 g" autocomplete="off"><p class="err" id="ed-err" hidden>Escribe el nombre del producto.</p></div>'+
    '<div class="row2"><div class="field"><label for="ed-cat">Categoría</label><span class="sel"><select class="input" id="ed-cat">'+cats.map(function(c){return '<option'+(c===e.category?' selected':'')+'>'+esc(c)+'</option>'}).join('')+'</select></span></div>'+
    '<div class="field"><label for="ed-badge">Etiqueta</label><span class="sel"><select class="input" id="ed-badge">'+BADGES.map(function(b){return '<option value="'+esc(b)+'"'+(b===(e.badge||'')?' selected':'')+'>'+(b||'Sin etiqueta')+'</option>'}).join('')+'</select></span></div></div>'+
    '<div class="field"><label for="ed-desc">Descripción para el dropshipper</label><textarea class="input" id="ed-desc" rows="5" placeholder="Contenido, modo de uso, público ideal, ángulos de venta…">'+esc(e.description)+'</textarea></div>'+
    '<div class="field"><span class="flabel">Fotos</span><div class="photos" id="ed-photos"></div><p class="hint">La primera foto es la portada. Puedes arrastrarlas aquí; se reducen automáticamente para que el catálogo cargue rápido.</p></div>'+
    '<div class="field"><label for="ed-media">Enlace a material de venta (opcional)</label><input class="input" id="ed-media" type="url" value="'+esc(e.media)+'" placeholder="https://drive.google.com/…"></div>'+
    '<div class="field"><span class="flabel">Precio y disponibilidad por país</span><div class="markets">'+(p.countries.map(function(cc){return mkRow(e,cc)}).join('')||'<p class="hint" style="padding:14px">Agrega países en Ajustes.</p>')+'</div></div></div></div>';
  var foot='<div class="m-foot"><div class="foot-l">'+(isNew?'':'<button class="btn danger" data-act="ed-delete">Eliminar</button><button class="btn" data-act="ed-dup">Duplicar</button>')+
    '</div><div class="foot-r"><button class="btn" data-act="close">Cancelar</button><button class="btn primary" data-act="ed-apply">'+(isNew?'Agregar producto':'Aplicar cambios')+'</button></div></div>';
  openModal(head(esc(p.name)+' · '+(isNew?'Nuevo producto':'Editar producto'),isNew?'Agregar producto':esc(e.name))+body+foot,'wide');
  ed=e;ed._new=isNew;renderPhotos();
}
function mkRow(e,cc){
  var m=e.markets[cc]||{},c=C(cc),sym=c.symbol?' ('+c.symbol+')':'';
  return '<div class="mk'+(m.active?'':' off')+'" data-cc="'+cc+'"><label class="mk-on"><input type="checkbox" id="m-'+cc+'-on" data-mk="'+cc+'"'+(m.active?' checked':'')+'><span class="iso">'+cc+'</span>Disponible en '+esc(c.name)+'</label>'+
    '<label class="f">Precio proveedor'+esc(sym)+'<input class="input num" id="m-'+cc+'-price" inputmode="decimal" value="'+(m.price!=null?m.price:'')+'" autocomplete="off"></label>'+
    '<label class="f">Venta sugerida'+esc(sym)+'<input class="input num" id="m-'+cc+'-sug" inputmode="decimal" value="'+(m.suggested!=null?m.suggested:'')+'" autocomplete="off"></label>'+
    '<label class="f">Estado<span class="sel"><select class="input" id="m-'+cc+'-st">'+Object.keys(STATUS).map(function(k){return '<option value="'+k+'"'+(k===(m.status||'disponible')?' selected':'')+'>'+STATUS[k].l+'</option>'}).join('')+'</select></span></label>'+
    '<label class="f">ID en '+esc(P().name)+'<input class="input" id="m-'+cc+'-code" value="'+esc(m.code||'')+'" placeholder="Opcional" autocomplete="off"></label></div>';
}
function renderPhotos(){
  var el=$('#ed-photos');if(!el||!ed)return;var a=ed.images;
  el.innerHTML=a.map(function(i,k){return '<div class="ph-item"><div class="im"><img src="'+esc(imgSrc(i))+'" alt="Foto '+(k+1)+'">'+(k===0?'<span class="cover-tag">Portada</span>':'')+'</div><div class="ph-tools"><button type="button" class="ic" data-act="img-move" data-i="'+k+'" data-d="-1"'+(k===0?' disabled':'')+' aria-label="Mover antes">←</button><button type="button" class="ic" data-act="img-del" data-i="'+k+'" aria-label="Quitar foto">✕</button><button type="button" class="ic" data-act="img-move" data-i="'+k+'" data-d="1"'+(k===a.length-1?' disabled':'')+' aria-label="Mover después">→</button></div></div>'}).join('')+
    '<label class="upload" id="ed-drop"><input type="file" id="ed-file" accept="image/*" multiple aria-label="Subir fotos"><span id="ed-up-t">+ Subir fotos</span></label>';
}
function collect(){
  var x=clone(ed);delete x._new;
  x.name=$('#ed-name').value.trim();x.category=$('#ed-cat').value;x.badge=$('#ed-badge').value;x.description=$('#ed-desc').value.trim();x.media=$('#ed-media').value.trim();
  P().countries.forEach(function(cc){x.markets[cc]={active:$('#m-'+cc+'-on').checked,price:parseNum($('#m-'+cc+'-price').value),suggested:parseNum($('#m-'+cc+'-sug').value),status:$('#m-'+cc+'-st').value,code:$('#m-'+cc+'-code').value.trim()}});
  return x;
}
function edApply(){
  var x=collect();if(!x.name){$('#ed-err').hidden=false;$('#ed-name').focus();return null}
  var i=state.products.findIndex(function(p){return p.id===x.id});
  if(i>=0)state.products[i]=x;else state.products.unshift(x);
  markDirty();return x;
}

function compress(file){
  return new Promise(function(res,rej){
    var r=new FileReader();r.onerror=rej;r.onload=function(){
      var img=new Image();img.onerror=rej;img.onload=function(){
        var max=1080,w=img.naturalWidth,h=img.naturalHeight,s=Math.min(1,max/Math.max(w,h));w=Math.round(w*s);h=Math.round(h*s);
        var c=document.createElement('canvas');c.width=w;c.height=h;var g=c.getContext('2d');g.fillStyle='#ffffff';g.fillRect(0,0,w,h);g.drawImage(img,0,0,w,h);
        var q=.85,out=c.toDataURL('image/jpeg',q);while(out.length>300000&&q>.55){q-=.07;out=c.toDataURL('image/jpeg',q)}res(out)};
      img.src=r.result};
    r.readAsDataURL(file)});
}
function addFiles(files){
  if(!ed)return;files=[].slice.call(files||[]).filter(function(f){return /^image\//.test(f.type)});if(!files.length)return;
  var t=$('#ed-up-t');if(t)t.textContent='Procesando…';
  var chain=Promise.resolve();
  files.forEach(function(f){chain=chain.then(function(){return compress(f).then(function(d){if(!ed)return;var path='img/'+uid('f')+'.jpg';pending[path]=d;ed.images.push(path)}).catch(function(){toast('No se pudo leer '+f.name+'. Prueba con JPG o PNG.')})})});
  chain.then(renderPhotos);
}

function openSettings(){
  var p=P(),b=state.brand;
  openModal(head('Ajustes','Catálogo '+esc(p.name))+'<div class="m-body"><div class="form">'+
    '<div class="field"><label for="st-wa">WhatsApp de consultas</label><input class="input" id="st-wa" inputmode="tel" value="'+esc(p.whatsapp)+'" placeholder="50212345678"><p class="hint">Con código de país, sin “+” ni espacios. Activa el botón Consultas.</p></div>'+
    '<div class="field"><span class="flabel">Países donde vendes con '+esc(p.name)+'</span><div id="st-countries"></div></div>'+
    '<div class="field"><label for="st-note">Mensaje para tus dropshippers (opcional)</label><textarea class="input" id="st-note" rows="2" placeholder="Ej. Despachamos de lunes a sábado. Pedidos antes de las 2 p. m. salen el mismo día.">'+esc(p.note)+'</textarea></div>'+
    '<div class="row2"><div class="field"><label for="st-bname">Nombre de la proveeduría</label><input class="input" id="st-bname" value="'+esc(b.name)+'"></div><div class="field"><label for="st-btag">Descripción corta</label><input class="input" id="st-btag" value="'+esc(b.tagline)+'" placeholder="Proveeduría multinicho"></div></div>'+
    '<div class="field"><label for="st-hl">Anuncio destacado (opcional)</label><input class="input" id="st-hl" value="'+esc(b.highlight)+'" placeholder="Abrimos la línea de Bienestar"></div>'+
    '<div class="field"><label for="st-cats">Categorías (una por línea)</label><textarea class="input" id="st-cats" rows="6">'+esc(state.categories.join('\n'))+'</textarea></div></div></div>'+
    '<div class="m-foot"><span></span><div class="foot-r"><button class="btn" data-act="close">Cancelar</button><button class="btn primary" data-act="st-apply">Aplicar</button></div></div>','sm');
  stg={countries:p.countries.slice()};renderStCountries();
}
function renderStCountries(){
  var el=$('#st-countries');if(!el||!stg)return;
  var avail=Object.keys(COUNTRY_LIB).filter(function(c){return stg.countries.indexOf(c)<0});
  el.innerHTML='<div class="cchips" style="margin-bottom:10px">'+(stg.countries.map(function(c){return '<span class="cchip"><span class="iso">'+c+'</span>'+esc(C(c).name)+'<button type="button" data-act="st-del-country" data-cc="'+c+'" aria-label="Quitar '+esc(C(c).name)+'">✕</button></span>'}).join('')||'<span class="hint">Sin países todavía.</span>')+'</div>'+
    (avail.length?'<div class="addc"><span class="sel"><select class="input" id="st-add" aria-label="País para agregar">'+avail.map(function(c){return '<option value="'+c+'">'+esc(C(c).name)+' ('+esc(C(c).symbol)+')</option>'}).join('')+'</select></span><button type="button" class="btn" data-act="st-add-country">Agregar país</button></div>':'');
}
function openShare(){
  var p=P(),base=publicUrl();
  var links=[{l:'Catálogo '+p.name+' (todos sus países)',u:base}].concat(p.countries.map(function(c){return {l:'Abre directo en '+C(c).name,u:base+'#'+c.toLowerCase()}}));
  openModal(head('Compartir con dropshippers','Enlaces de '+esc(p.name))+'<div class="m-body"><div class="form">'+
    links.map(function(k,i){return '<div class="field"><label for="sh-'+i+'">'+esc(k.l)+'</label><div class="copyrow"><input class="input" id="sh-'+i+'" readonly value="'+esc(k.u)+'"><button class="btn" data-act="copy" data-text="'+esc(k.u)+'" data-for="sh-'+i+'">Copiar</button></div></div>'}).join('')+
    '<div class="tipbox"><strong>Qué ven tus dropshippers</strong><p>Solo los productos de '+esc(p.name)+' y sus países. No ven este panel ni los catálogos de otras plataformas.</p></div></div></div>','sm');
}

/* ---------- GitHub ---------- */
function detectRepo(){
  var host=location.hostname,parts=location.pathname.split('/').filter(Boolean),idx=parts.lastIndexOf('admin');
  var owner='',repo='',start=0;
  if(/\.github\.io$/.test(host)){owner=host.split('.')[0];
    if(idx>=2){repo=parts[0];start=1}else{repo=host;start=0}}
  var saved={};try{saved=JSON.parse(lsGet(REPO_KEY)||'{}')}catch(e){}
  return {owner:owner||saved.owner||'',repo:repo||saved.repo||'',dir:parts.slice(start,idx).join('/')||saved.dir||''};
}
function api(path,opt){
  opt=opt||{};
  return fetch('https://api.github.com'+path,{method:opt.method||'GET',cache:'no-store',headers:{'Authorization':'Bearer '+gh.token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'},body:opt.body?JSON.stringify(opt.body):undefined})
  .then(function(r){
    if(r.ok)return r.status===204?null:r.json();
    return r.json().catch(function(){return {}}).then(function(b){var e=new Error((b&&b.message)||('GitHub '+r.status));e.status=r.status;throw e});
  });
}
function enc(p){return p.split('/').map(encodeURIComponent).join('/')}
function b64utf8(s){var bin=atob(String(s).replace(/\s/g,''));var bytes=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);return new TextDecoder().decode(bytes)}
function R(){return '/repos/'+encodeURIComponent(gh.owner)+'/'+encodeURIComponent(gh.repo)}
function ghError(e){
  if(!e||!e.status)return 'No hay conexión con GitHub. Revisa tu internet e intenta de nuevo.';
  if(e.status===401)return 'El token no es válido o ya venció. Crea uno nuevo y vuelve a entrar.';
  if(e.status===403)return 'El token no tiene permiso para escribir en este repositorio (Contents: Read and write).';
  if(e.status===404)return 'No encontré el repositorio o la carpeta. Revisa el usuario y el nombre del repositorio.';
  if(e.status===409||e.status===422)return 'Alguien publicó cambios al mismo tiempo. Recarga el panel e intenta de nuevo.';
  return 'GitHub respondió: '+e.message;
}
function ghLoad(){
  return api(R()).then(function(repo){
    if(repo.permissions&&!repo.permissions.push){var e=new Error('perm');e.status=403;throw e}
    gh.branch=repo.default_branch||'main';
    return api(R()+'/contents/'+enc(gh.dir+'/data.json')+'?ref='+encodeURIComponent(gh.branch));
  }).then(function(f){
    loadedSha=f.sha;state=normalize(JSON.parse(b64utf8(f.content)));
    origImages={};state.products.forEach(function(x){(x.images||[]).forEach(function(i){origImages[i]=1})});
  });
}
function ghSave(){
  var dir=gh.dir,used={},head,tree=[],newPaths=[];
  state.products.forEach(function(x){(x.images||[]).forEach(function(i){used[i]=1})});
  state.updatedAt=new Date().toISOString();
  return api(R()+'/contents/'+enc(dir+'/data.json')+'?ref='+encodeURIComponent(gh.branch)).then(function(f){
    if(f.sha!==loadedSha){var e=new Error('conflict');e.status=409;throw e}
    return api(R()+'/git/ref/heads/'+enc(gh.branch));
  }).then(function(ref){head=ref.object.sha;return api(R()+'/git/commits/'+head)}).then(function(commit){
    var chain=Promise.resolve();
    Object.keys(pending).forEach(function(p){if(!used[p])return;newPaths.push(p);
      chain=chain.then(function(){return api(R()+'/git/blobs',{method:'POST',body:{content:pending[p].split(',')[1],encoding:'base64'}}).then(function(b){tree.push({path:dir+'/'+p,mode:'100644',type:'blob',sha:b.sha})})})});
    return chain.then(function(){
      Object.keys(origImages).forEach(function(p){if(!used[p]&&/^img\//.test(p))tree.push({path:dir+'/'+p,mode:'100644',type:'blob',sha:null})});
      tree.push({path:dir+'/data.json',mode:'100644',type:'blob',content:JSON.stringify(state,null,1)+'\n'});
      return api(R()+'/git/trees',{method:'POST',body:{base_tree:commit.tree.sha,tree:tree}});
    });
  }).then(function(t){
    return api(R()+'/git/commits',{method:'POST',body:{message:'Catálogo '+P().name+': actualización desde el panel',tree:t.sha,parents:[head]}});
  }).then(function(c){
    return api(R()+'/git/refs/heads/'+enc(gh.branch),{method:'PATCH',body:{sha:c.sha}});
  }).then(function(){
    return api(R()+'/contents/'+enc(dir+'/data.json')+'?ref='+encodeURIComponent(gh.branch));
  }).then(function(f){
    loadedSha=f.sha;newPaths.forEach(function(p){preview[p]=pending[p]});pending={};origImages=used;
  });
}

function save(){
  if(saving||!dirty)return;
  saving=true;render();
  var prev=state.updatedAt;
  ghSave().then(function(){saving=false;dirty=0;render();toast('Publicado. El catálogo se actualiza en 1 a 2 minutos.',5000)})
  .catch(function(e){saving=false;state.updatedAt=prev;render();toast(ghError(e),8000)});
}

function renderLogin(msg,prev){
  var d=prev||detectRepo();
  document.title='Entrar al panel · Grupo Blue';
  app.innerHTML='<div class="wrap"><form class="login" id="login"><div class="ab-title"><span class="mini">GB</span>Panel del catálogo</div><h1>Entrar al panel'+(d.dir?' de '+esc(d.dir.charAt(0).toUpperCase()+d.dir.slice(1)):'')+'</h1>'+
    '<p class="lead">Pega tu token de GitHub. Solo se guarda en este navegador; los dropshippers nunca lo ven.</p>'+
    (msg?'<p class="err">'+esc(msg)+'</p>':'')+
    '<div class="field"><label for="lg-token">Token de GitHub</label><input class="input" id="lg-token" type="password" autocomplete="off" placeholder="github_pat_…" required></div>'+
    '<div class="row2"><div class="field"><label for="lg-owner">Usuario de GitHub</label><input class="input" id="lg-owner" value="'+esc(d.owner)+'" required></div><div class="field"><label for="lg-repo">Repositorio</label><input class="input" id="lg-repo" value="'+esc(d.repo)+'" required></div></div>'+
    '<div class="field"><label for="lg-dir">Carpeta del catálogo</label><input class="input" id="lg-dir" value="'+esc(d.dir)+'" required></div>'+
    '<button class="btn primary" type="submit">Entrar</button>'+
    '<details><summary>¿Cómo creo el token?</summary><ol><li>En GitHub: tu foto → Settings → Developer settings.</li><li>Personal access tokens → Fine-grained tokens → Generate new token.</li><li>Repository access: Only select repositories → elige el del catálogo.</li><li>Permissions → Repository → Contents: Read and write.</li><li>Genera el token, cópialo y pégalo aquí.</li></ol></details></form></div>';
  $('#lg-token').focus();
}
function startAdmin(cfg){
  gh=cfg;app.innerHTML='<div class="loading">Cargando el panel…</div>';
  ghLoad().then(function(){
    lsSet(TOKEN_KEY,gh.token);lsSet(REPO_KEY,JSON.stringify({owner:gh.owner,repo:gh.repo,dir:gh.dir}));
    applyHash();render();
  }).catch(function(e){if(e&&(e.status===401||e.status===403))lsSet(TOKEN_KEY,null);renderLogin(ghError(e),{owner:cfg.owner,repo:cfg.repo,dir:cfg.dir})});
}

/* ---------- Utilidades ---------- */
function markDirty(){dirty++}
var toastT=null;
function toast(msg,ms){var t=$('.toast');if(!t){t=document.createElement('div');t.className='toast';t.setAttribute('role','status');document.body.appendChild(t)}t.textContent=msg;t.hidden=false;clearTimeout(toastT);toastT=setTimeout(function(){t.hidden=true},ms||3200)}
function copy(text,inputId){
  function fallback(){var i=inputId&&document.getElementById(inputId);if(i){i.focus();i.select()}toast('Selecciona el texto y cópialo con Ctrl+C')}
  try{navigator.clipboard.writeText(text).then(function(){toast('Copiado')},fallback)}catch(e){fallback()}
}
function arm(t,fn){
  if(t.classList.contains('armed')){fn();return}
  t.classList.add('armed');t.dataset.orig=t.textContent;t.textContent='¿Seguro? Toca de nuevo';
  setTimeout(function(){if(t.isConnected&&t.classList.contains('armed')){t.classList.remove('armed');t.textContent=t.dataset.orig}},4000);
}

/* ---------- Eventos ---------- */
var H={
  country:function(t){ui.country=t.dataset.cc;ui.cat='Todas';if(!admin){try{history.replaceState(null,'','#'+ui.country.toLowerCase())}catch(e){}}render()},
  cat:function(t){ui.cat=t.dataset.v;renderResults()},
  scope:function(t){ui.scope=t.dataset.v;renderResults()},
  open:function(t){if(admin)openEditor(t.dataset.id);else openDetail(t.dataset.id)},
  close:function(){closeModal()},
  thumb:function(t){var m=$('#dt-main');if(m)m.innerHTML='<img src="'+esc(imgSrc(t.dataset.img))+'" alt="">';[].forEach.call(t.parentNode.children,function(b){b.setAttribute('aria-pressed',b===t?'true':'false')})},
  copy:function(t){copy(t.dataset.text,t.dataset.for)},
  settings:function(){openSettings()},
  share:function(){openShare()},
  save:function(){save()},
  logout:function(t){if(dirty&&!t.classList.contains('armed')){arm(t,function(){});t.textContent='Hay cambios sin publicar. ¿Salir?';return}lsSet(TOKEN_KEY,null);dirty=0;gh=null;state=null;renderLogin('')},
  'add-product':function(){openEditor(null)},
  'img-move':function(t){var i=+t.dataset.i,d=+t.dataset.d,a=ed.images,j=i+d;if(j<0||j>=a.length)return;var v=a[i];a[i]=a[j];a[j]=v;renderPhotos()},
  'img-del':function(t){ed.images.splice(+t.dataset.i,1);renderPhotos()},
  'ed-apply':function(){var isNew=ed._new;if(edApply()){closeModal();render();toast((isNew?'Producto agregado':'Cambios aplicados')+'. Recuerda guardar y publicar.')}},
  'ed-delete':function(t){arm(t,function(){var id=ed.id;state.products=state.products.filter(function(x){return x.id!==id});closeModal();markDirty();render();toast('Producto eliminado. Recuerda guardar y publicar.')})},
  'ed-dup':function(){var x=edApply();if(!x)return;var c=clone(x);c.id=uid('p');c.name=x.name+' (copia)';var i=state.products.findIndex(function(p){return p.id===x.id});state.products.splice(i+1,0,c);markDirty();render();openEditor(c.id);toast('Copia creada')},
  'st-add-country':function(){var s=$('#st-add');if(s&&stg.countries.indexOf(s.value)<0){stg.countries.push(s.value);renderStCountries()}},
  'st-del-country':function(t){stg.countries=stg.countries.filter(function(c){return c!==t.dataset.cc});renderStCountries()},
  'st-apply':function(){
    var p=P(),b=state.brand;
    p.whatsapp=$('#st-wa').value.replace(/\D/g,'');p.note=$('#st-note').value.trim();p.countries=stg.countries.slice();
    b.name=$('#st-bname').value.trim()||'Grupo Blue';b.tagline=$('#st-btag').value.trim();b.highlight=$('#st-hl').value.trim();
    var cats=uniq($('#st-cats').value.split('\n').map(function(s){return s.trim()}).filter(Boolean));state.categories=cats.length?cats:['Otros'];
    if(p.countries.indexOf(ui.country)<0)ui.country=p.countries[0]||'';
    markDirty();closeModal();render();toast('Ajustes aplicados. Recuerda guardar y publicar.')}
};
document.addEventListener('click',function(e){var t=e.target.closest('[data-act]');if(!t||t.disabled)return;var f=H[t.dataset.act];if(f){e.preventDefault();f(t,e)}});
document.addEventListener('keydown',function(e){
  if(e.key==='Escape'&&modal){closeModal();return}
  if((e.key==='Enter'||e.key===' ')&&e.target.matches&&e.target.matches('article[data-act]')){e.preventDefault();e.target.click()}
});
document.addEventListener('input',function(e){if(e.target.id==='q'){ui.q=e.target.value;renderResults()}});
document.addEventListener('change',function(e){
  var t=e.target;
  if(t.id==='sort'){ui.sort=t.value;renderResults()}
  else if(t.dataset&&t.dataset.mk){var row=t.closest('.mk');if(row)row.classList.toggle('off',!t.checked)}
  else if(t.id==='ed-file'){addFiles(t.files);t.value=''}
});
document.addEventListener('submit',function(e){
  if(e.target.id!=='login')return;e.preventDefault();
  startAdmin({token:$('#lg-token').value.trim(),owner:$('#lg-owner').value.trim(),repo:$('#lg-repo').value.trim(),dir:$('#lg-dir').value.trim().replace(/^\/+|\/+$/g,'')});
});
document.addEventListener('dragover',function(e){var d=e.target.closest&&e.target.closest('#ed-drop');if(d){e.preventDefault();d.classList.add('over')}});
document.addEventListener('dragleave',function(e){var d=e.target.closest&&e.target.closest('#ed-drop');if(d)d.classList.remove('over')});
document.addEventListener('drop',function(e){var d=e.target.closest&&e.target.closest('#ed-drop');if(d){e.preventDefault();d.classList.remove('over');addFiles(e.dataTransfer.files)}});
window.addEventListener('hashchange',function(){if(state){applyHash();render()}});
window.addEventListener('beforeunload',function(e){if(admin&&dirty){e.preventDefault();e.returnValue=''}});

/* ---------- Arranque ---------- */
if(admin){
  var token=lsGet(TOKEN_KEY),d=detectRepo();
  if(token&&d.owner&&d.repo&&d.dir)startAdmin({token:token,owner:d.owner,repo:d.repo,dir:d.dir});else renderLogin('');
}else{
  app.innerHTML='<div class="loading">Cargando catálogo…</div>';
  fetch('data.json?v='+Date.now(),{cache:'no-store'}).then(function(r){if(!r.ok)throw new Error(r.status);return r.json()}).then(function(d){state=normalize(d);applyHash();render()})
  .catch(function(){app.innerHTML='<div class="wrap">'+empty('No pudimos cargar el catálogo','Revisa tu conexión y vuelve a abrir el enlace.','')+'</div>'});
}
})();
